module.exports = {
    client: {
        service: {
            name: "redo-dev",
            url: "http://localhost:4000/graphql"
        }
    }
}
