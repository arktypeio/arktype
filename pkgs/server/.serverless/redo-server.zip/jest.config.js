module.exports = {
    ...require("@re-do/recommended/jest")
}
