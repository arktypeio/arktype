import { server } from "."
exports.handler = server.createHandler()
