import "dotenv/config"
import "reflect-metadata"
import "@re-do/model"
import { generateSchema } from "./generateSchema"

generateSchema({})
