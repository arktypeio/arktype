"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const runtime_1 = require("./runtime");
const path = require("path");
const debug = runtime_1.debugLib('photon');
class PhotonFetcher {
    constructor(photon, engine, debug = false, hooks) {
        this.photon = photon;
        this.engine = engine;
        this.debug = debug;
        this.hooks = hooks;
    }
    request(document, path = [], rootField, typeName, isList) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = String(document);
            debug(query);
            if (this.hooks && this.hooks.beforeRequest) {
                this.hooks.beforeRequest({ query, path, rootField, typeName, document });
            }
            yield this.photon.connect();
            try {
                const result = yield this.engine.request(query, typeName);
                debug(result);
                return this.unpack(result, path, rootField, isList);
            }
            catch (e) {
                throw new Error(`Error in Photon${path}: \n` + e.message);
            }
        });
    }
    unpack(data, path, rootField, isList) {
        const getPath = [];
        if (rootField) {
            getPath.push(rootField);
        }
        getPath.push(...path.filter(p => p !== 'select' && p !== 'include'));
        const result = runtime_1.deepGet(data, getPath) || null;
        if (result === null && isList) {
            return [];
        }
        return result;
    }
}
/**
 * Build tool annotations
 * In order to make `ncc` and `node-file-trace` happy.
**/
path.join(__dirname, 'runtime/query-engine-darwin');
path.join(__dirname, 'runtime/query-engine-linux-glibc-libssl1.0.2');
function uniqueBy(arr, cb) {
    var a = arr.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (cb(a[i]) === cb(a[j]))
                a.splice(j--, 1);
        }
    }
    return a;
}
class Photon {
    constructor(options = {}) {
        const useDebug = options.debug === true ? true : typeof options.debug === 'object' ? Boolean(options.debug.library) : false;
        if (useDebug) {
            runtime_1.debugLib.enable('photon');
        }
        const debugEngine = options.debug === true ? true : typeof options.debug === 'object' ? Boolean(options.debug.engine) : false;
        // datamodel = datamodel without datasources + printed datasources
        this.datamodel = "datasource db {\n  provider = \"sqlite\"\n  url      = \"file:dev.db\"\n  default  = true\n}\n\ngenerator photon {\n  provider = \"photonjs\"\n  platforms = [\"native\", \"linux-glibc-libssl1.0.2\"] \n}\n\nmodel User {\n  id String @default(cuid()) @id @unique\n  email String @unique\n  password String\n  firstName String\n  lastName String\n}\n\nmodel Session {\n  id String @default(cuid()) @id @unique\n  token String\n  user User\n}\n\nmodel Step {\n  id String @default(cuid()) @id @unique\n  key String\n  selector String\n  value String\n  user User\n}\n\nmodel Tag {\n  id String @default(cuid()) @id @unique\n  name String @unique\n  user User\n}\n\nmodel Test {\n  id String @default(cuid()) @id @unique\n  user User\n  name String\n  tags Tag[]\n  steps Step[]\n}\n\n";
        const predefinedDatasources = [
            {
                "name": "db",
                "url": 'file:' + path.resolve(__dirname, '../../../prisma/dev.db')
            }
        ];
        const inputDatasources = Object.entries(options.datasources || {}).map(([name, url]) => ({ name, url: url }));
        const datasources = uniqueBy([...predefinedDatasources, ...inputDatasources], source => source.name);
        const internal = options.__internal || {};
        const engineConfig = internal.engine || {};
        this.engine = new runtime_1.Engine({
            cwd: engineConfig.cwd,
            debug: debugEngine,
            datamodel: this.datamodel,
            prismaPath: engineConfig.binaryPath || undefined,
            datasources,
            generator: { "name": "photon", "provider": "photonjs", "output": "/Users/Sarthak/redo/pkgs/redo-server/node_modules/@generated/photon", "platforms": ["native", "linux-glibc-libssl1.0.2"], "pinnedPlatform": null, "config": {} },
            platform: undefined
        });
        this.dmmf = new runtime_1.DMMFClass(exports.dmmf);
        this.fetcher = new PhotonFetcher(this, this.engine, false, internal.hooks);
    }
    connectEngine(publicCall) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.engine.start();
        });
    }
    connect() {
        if (this.connectionPromise) {
            return this.connectionPromise;
        }
        this.connectionPromise = this.connectEngine(true);
        return this.connectionPromise;
    }
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.engine.stop();
        });
    }
    // won't be generated for now
    // private _query?: QueryDelegate
    // get query(): QueryDelegate {
    //   return this._query ? this._query: (this._query = QueryDelegate(this.dmmf, this.fetcher))
    // }
    get users() {
        return UserDelegate(this.dmmf, this.fetcher);
    }
    get sessions() {
        return SessionDelegate(this.dmmf, this.fetcher);
    }
    get steps() {
        return StepDelegate(this.dmmf, this.fetcher);
    }
    get tags() {
        return TagDelegate(this.dmmf, this.fetcher);
    }
    get tests() {
        return TestDelegate(this.dmmf, this.fetcher);
    }
}
exports.default = Photon;
/**
 * Enums
 */
// Based on
// https://github.com/microsoft/TypeScript/issues/3192#issuecomment-261720275
function makeEnum(x) { return x; }
exports.OrderByArg = makeEnum({
    asc: 'asc',
    desc: 'desc'
});
function UserDelegate(dmmf, fetcher) {
    const User = (args) => new UserClient(dmmf, fetcher, 'query', 'findManyUser', 'users', args, []);
    User.findOne = (args) => args.select ? new UserClient(dmmf, fetcher, 'query', 'findOneUser', 'users.findOne', args, []) : new UserClient(dmmf, fetcher, 'query', 'findOneUser', 'users.findOne', args, []);
    User.findMany = (args) => new UserClient(dmmf, fetcher, 'query', 'findManyUser', 'users.findMany', args, []);
    User.create = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'createOneUser', 'users.create', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'createOneUser', 'users.create', args, []);
    User.delete = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'deleteOneUser', 'users.delete', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'deleteOneUser', 'users.delete', args, []);
    User.update = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'updateOneUser', 'users.update', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'updateOneUser', 'users.update', args, []);
    User.deleteMany = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'deleteManyUser', 'users.deleteMany', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'deleteManyUser', 'users.deleteMany', args, []);
    User.updateMany = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'updateManyUser', 'users.updateMany', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'updateManyUser', 'users.updateMany', args, []);
    User.upsert = (args) => args.select ? new UserClient(dmmf, fetcher, 'mutation', 'upsertOneUser', 'users.upsert', args, []) : new UserClient(dmmf, fetcher, 'mutation', 'upsertOneUser', 'users.upsert', args, []);
    return User; // any needed until https://github.com/microsoft/TypeScript/issues/31335 is resolved
}
class UserClient {
    constructor(_dmmf, _fetcher, _queryType, _rootField, _clientMethod, _args, _path, _isList = false) {
        this._dmmf = _dmmf;
        this._fetcher = _fetcher;
        this._queryType = _queryType;
        this._rootField = _rootField;
        this._clientMethod = _clientMethod;
        this._args = _args;
        this._path = _path;
        this._isList = _isList;
        // @ts-ignore
        if (typeof window === 'undefined' && process.env.NODE_ENV !== 'production') {
            const error = new Error();
            if (error && error.stack) {
                const stack = error.stack;
                this._callsite = stack;
            }
        }
    }
    session(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'session'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new SessionClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    step(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'step'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new StepClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    tag(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'tag'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new TagClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    test(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'test'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new TestClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    get _document() {
        const { _rootField: rootField } = this;
        const document = runtime_1.makeDocument({
            dmmf: this._dmmf,
            rootField,
            rootTypeName: this._queryType,
            select: this._args
        });
        try {
            document.validate(this._args, false, this._clientMethod);
        }
        catch (e) {
            const x = e;
            if (x.render) {
                if (this._callsite) {
                    e.message = x.render(this._callsite);
                }
            }
            throw e;
        }
        debug(String(document));
        return runtime_1.transformDocument(document);
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'User', this._isList);
        }
        return this._requestPromise.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'User', this._isList);
        }
        return this._requestPromise.catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'User', this._isList);
        }
        return this._requestPromise.finally(onfinally);
    }
}
exports.UserClient = UserClient;
function SessionDelegate(dmmf, fetcher) {
    const Session = (args) => new SessionClient(dmmf, fetcher, 'query', 'findManySession', 'sessions', args, []);
    Session.findOne = (args) => args.select ? new SessionClient(dmmf, fetcher, 'query', 'findOneSession', 'sessions.findOne', args, []) : new SessionClient(dmmf, fetcher, 'query', 'findOneSession', 'sessions.findOne', args, []);
    Session.findMany = (args) => new SessionClient(dmmf, fetcher, 'query', 'findManySession', 'sessions.findMany', args, []);
    Session.create = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'createOneSession', 'sessions.create', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'createOneSession', 'sessions.create', args, []);
    Session.delete = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'deleteOneSession', 'sessions.delete', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'deleteOneSession', 'sessions.delete', args, []);
    Session.update = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'updateOneSession', 'sessions.update', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'updateOneSession', 'sessions.update', args, []);
    Session.deleteMany = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'deleteManySession', 'sessions.deleteMany', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'deleteManySession', 'sessions.deleteMany', args, []);
    Session.updateMany = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'updateManySession', 'sessions.updateMany', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'updateManySession', 'sessions.updateMany', args, []);
    Session.upsert = (args) => args.select ? new SessionClient(dmmf, fetcher, 'mutation', 'upsertOneSession', 'sessions.upsert', args, []) : new SessionClient(dmmf, fetcher, 'mutation', 'upsertOneSession', 'sessions.upsert', args, []);
    return Session; // any needed until https://github.com/microsoft/TypeScript/issues/31335 is resolved
}
class SessionClient {
    constructor(_dmmf, _fetcher, _queryType, _rootField, _clientMethod, _args, _path, _isList = false) {
        this._dmmf = _dmmf;
        this._fetcher = _fetcher;
        this._queryType = _queryType;
        this._rootField = _rootField;
        this._clientMethod = _clientMethod;
        this._args = _args;
        this._path = _path;
        this._isList = _isList;
        // @ts-ignore
        if (typeof window === 'undefined' && process.env.NODE_ENV !== 'production') {
            const error = new Error();
            if (error && error.stack) {
                const stack = error.stack;
                this._callsite = stack;
            }
        }
    }
    user(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'user'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new UserClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    get _document() {
        const { _rootField: rootField } = this;
        const document = runtime_1.makeDocument({
            dmmf: this._dmmf,
            rootField,
            rootTypeName: this._queryType,
            select: this._args
        });
        try {
            document.validate(this._args, false, this._clientMethod);
        }
        catch (e) {
            const x = e;
            if (x.render) {
                if (this._callsite) {
                    e.message = x.render(this._callsite);
                }
            }
            throw e;
        }
        debug(String(document));
        return runtime_1.transformDocument(document);
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Session', this._isList);
        }
        return this._requestPromise.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Session', this._isList);
        }
        return this._requestPromise.catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Session', this._isList);
        }
        return this._requestPromise.finally(onfinally);
    }
}
exports.SessionClient = SessionClient;
function StepDelegate(dmmf, fetcher) {
    const Step = (args) => new StepClient(dmmf, fetcher, 'query', 'findManyStep', 'steps', args, []);
    Step.findOne = (args) => args.select ? new StepClient(dmmf, fetcher, 'query', 'findOneStep', 'steps.findOne', args, []) : new StepClient(dmmf, fetcher, 'query', 'findOneStep', 'steps.findOne', args, []);
    Step.findMany = (args) => new StepClient(dmmf, fetcher, 'query', 'findManyStep', 'steps.findMany', args, []);
    Step.create = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'createOneStep', 'steps.create', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'createOneStep', 'steps.create', args, []);
    Step.delete = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'deleteOneStep', 'steps.delete', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'deleteOneStep', 'steps.delete', args, []);
    Step.update = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'updateOneStep', 'steps.update', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'updateOneStep', 'steps.update', args, []);
    Step.deleteMany = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'deleteManyStep', 'steps.deleteMany', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'deleteManyStep', 'steps.deleteMany', args, []);
    Step.updateMany = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'updateManyStep', 'steps.updateMany', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'updateManyStep', 'steps.updateMany', args, []);
    Step.upsert = (args) => args.select ? new StepClient(dmmf, fetcher, 'mutation', 'upsertOneStep', 'steps.upsert', args, []) : new StepClient(dmmf, fetcher, 'mutation', 'upsertOneStep', 'steps.upsert', args, []);
    return Step; // any needed until https://github.com/microsoft/TypeScript/issues/31335 is resolved
}
class StepClient {
    constructor(_dmmf, _fetcher, _queryType, _rootField, _clientMethod, _args, _path, _isList = false) {
        this._dmmf = _dmmf;
        this._fetcher = _fetcher;
        this._queryType = _queryType;
        this._rootField = _rootField;
        this._clientMethod = _clientMethod;
        this._args = _args;
        this._path = _path;
        this._isList = _isList;
        // @ts-ignore
        if (typeof window === 'undefined' && process.env.NODE_ENV !== 'production') {
            const error = new Error();
            if (error && error.stack) {
                const stack = error.stack;
                this._callsite = stack;
            }
        }
    }
    user(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'user'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new UserClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    test(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'test'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new TestClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    get _document() {
        const { _rootField: rootField } = this;
        const document = runtime_1.makeDocument({
            dmmf: this._dmmf,
            rootField,
            rootTypeName: this._queryType,
            select: this._args
        });
        try {
            document.validate(this._args, false, this._clientMethod);
        }
        catch (e) {
            const x = e;
            if (x.render) {
                if (this._callsite) {
                    e.message = x.render(this._callsite);
                }
            }
            throw e;
        }
        debug(String(document));
        return runtime_1.transformDocument(document);
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Step', this._isList);
        }
        return this._requestPromise.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Step', this._isList);
        }
        return this._requestPromise.catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Step', this._isList);
        }
        return this._requestPromise.finally(onfinally);
    }
}
exports.StepClient = StepClient;
function TagDelegate(dmmf, fetcher) {
    const Tag = (args) => new TagClient(dmmf, fetcher, 'query', 'findManyTag', 'tags', args, []);
    Tag.findOne = (args) => args.select ? new TagClient(dmmf, fetcher, 'query', 'findOneTag', 'tags.findOne', args, []) : new TagClient(dmmf, fetcher, 'query', 'findOneTag', 'tags.findOne', args, []);
    Tag.findMany = (args) => new TagClient(dmmf, fetcher, 'query', 'findManyTag', 'tags.findMany', args, []);
    Tag.create = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'createOneTag', 'tags.create', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'createOneTag', 'tags.create', args, []);
    Tag.delete = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'deleteOneTag', 'tags.delete', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'deleteOneTag', 'tags.delete', args, []);
    Tag.update = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'updateOneTag', 'tags.update', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'updateOneTag', 'tags.update', args, []);
    Tag.deleteMany = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'deleteManyTag', 'tags.deleteMany', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'deleteManyTag', 'tags.deleteMany', args, []);
    Tag.updateMany = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'updateManyTag', 'tags.updateMany', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'updateManyTag', 'tags.updateMany', args, []);
    Tag.upsert = (args) => args.select ? new TagClient(dmmf, fetcher, 'mutation', 'upsertOneTag', 'tags.upsert', args, []) : new TagClient(dmmf, fetcher, 'mutation', 'upsertOneTag', 'tags.upsert', args, []);
    return Tag; // any needed until https://github.com/microsoft/TypeScript/issues/31335 is resolved
}
class TagClient {
    constructor(_dmmf, _fetcher, _queryType, _rootField, _clientMethod, _args, _path, _isList = false) {
        this._dmmf = _dmmf;
        this._fetcher = _fetcher;
        this._queryType = _queryType;
        this._rootField = _rootField;
        this._clientMethod = _clientMethod;
        this._args = _args;
        this._path = _path;
        this._isList = _isList;
        // @ts-ignore
        if (typeof window === 'undefined' && process.env.NODE_ENV !== 'production') {
            const error = new Error();
            if (error && error.stack) {
                const stack = error.stack;
                this._callsite = stack;
            }
        }
    }
    user(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'user'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new UserClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    test(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'test'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new TestClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    get _document() {
        const { _rootField: rootField } = this;
        const document = runtime_1.makeDocument({
            dmmf: this._dmmf,
            rootField,
            rootTypeName: this._queryType,
            select: this._args
        });
        try {
            document.validate(this._args, false, this._clientMethod);
        }
        catch (e) {
            const x = e;
            if (x.render) {
                if (this._callsite) {
                    e.message = x.render(this._callsite);
                }
            }
            throw e;
        }
        debug(String(document));
        return runtime_1.transformDocument(document);
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Tag', this._isList);
        }
        return this._requestPromise.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Tag', this._isList);
        }
        return this._requestPromise.catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Tag', this._isList);
        }
        return this._requestPromise.finally(onfinally);
    }
}
exports.TagClient = TagClient;
function TestDelegate(dmmf, fetcher) {
    const Test = (args) => new TestClient(dmmf, fetcher, 'query', 'findManyTest', 'tests', args, []);
    Test.findOne = (args) => args.select ? new TestClient(dmmf, fetcher, 'query', 'findOneTest', 'tests.findOne', args, []) : new TestClient(dmmf, fetcher, 'query', 'findOneTest', 'tests.findOne', args, []);
    Test.findMany = (args) => new TestClient(dmmf, fetcher, 'query', 'findManyTest', 'tests.findMany', args, []);
    Test.create = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'createOneTest', 'tests.create', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'createOneTest', 'tests.create', args, []);
    Test.delete = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'deleteOneTest', 'tests.delete', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'deleteOneTest', 'tests.delete', args, []);
    Test.update = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'updateOneTest', 'tests.update', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'updateOneTest', 'tests.update', args, []);
    Test.deleteMany = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'deleteManyTest', 'tests.deleteMany', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'deleteManyTest', 'tests.deleteMany', args, []);
    Test.updateMany = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'updateManyTest', 'tests.updateMany', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'updateManyTest', 'tests.updateMany', args, []);
    Test.upsert = (args) => args.select ? new TestClient(dmmf, fetcher, 'mutation', 'upsertOneTest', 'tests.upsert', args, []) : new TestClient(dmmf, fetcher, 'mutation', 'upsertOneTest', 'tests.upsert', args, []);
    return Test; // any needed until https://github.com/microsoft/TypeScript/issues/31335 is resolved
}
class TestClient {
    constructor(_dmmf, _fetcher, _queryType, _rootField, _clientMethod, _args, _path, _isList = false) {
        this._dmmf = _dmmf;
        this._fetcher = _fetcher;
        this._queryType = _queryType;
        this._rootField = _rootField;
        this._clientMethod = _clientMethod;
        this._args = _args;
        this._path = _path;
        this._isList = _isList;
        // @ts-ignore
        if (typeof window === 'undefined' && process.env.NODE_ENV !== 'production') {
            const error = new Error();
            if (error && error.stack) {
                const stack = error.stack;
                this._callsite = stack;
            }
        }
    }
    user(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'user'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = false;
        return new UserClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    tags(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'tags'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = true;
        return new TagClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    steps(args) {
        const prefix = this._path.includes('select') ? 'select' : this._path.includes('include') ? 'include' : 'select';
        const path = [...this._path, prefix, 'steps'];
        const newArgs = runtime_1.deepSet(this._args, path, args || true);
        this._isList = true;
        return new StepClient(this._dmmf, this._fetcher, this._queryType, this._rootField, this._clientMethod, newArgs, path, this._isList);
    }
    get _document() {
        const { _rootField: rootField } = this;
        const document = runtime_1.makeDocument({
            dmmf: this._dmmf,
            rootField,
            rootTypeName: this._queryType,
            select: this._args
        });
        try {
            document.validate(this._args, false, this._clientMethod);
        }
        catch (e) {
            const x = e;
            if (x.render) {
                if (this._callsite) {
                    e.message = x.render(this._callsite);
                }
            }
            throw e;
        }
        debug(String(document));
        return runtime_1.transformDocument(document);
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Test', this._isList);
        }
        return this._requestPromise.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Test', this._isList);
        }
        return this._requestPromise.catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally) {
        if (!this._requestPromise) {
            this._requestPromise = this._fetcher.request(this._document, this._path, this._rootField, 'Test', this._isList);
        }
        return this._requestPromise.finally(onfinally);
    }
}
exports.TestClient = TestClient;
/**
 * DMMF
 */
exports.dmmf = { "datamodel": { "enums": [], "models": [{ "name": "User", "isEmbedded": false, "dbName": null, "fields": [{ "name": "id", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": true, "type": "String", "default": { "name": "cuid", "returnType": "String", "args": [] }, "isGenerated": false, "isUpdatedAt": false }, { "name": "email", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "password", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "firstName", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "lastName", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "session", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Session", "relationName": "SessionToUser", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }, { "name": "step", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Step", "relationName": "StepToUser", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }, { "name": "tag", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Tag", "relationName": "TagToUser", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }, { "name": "test", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Test", "relationName": "TestToUser", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }], "isGenerated": false }, { "name": "Session", "isEmbedded": false, "dbName": null, "fields": [{ "name": "id", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": true, "type": "String", "default": { "name": "cuid", "returnType": "String", "args": [] }, "isGenerated": false, "isUpdatedAt": false }, { "name": "token", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "user", "kind": "object", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "User", "relationName": "SessionToUser", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }], "isGenerated": false }, { "name": "Step", "isEmbedded": false, "dbName": null, "fields": [{ "name": "id", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": true, "type": "String", "default": { "name": "cuid", "returnType": "String", "args": [] }, "isGenerated": false, "isUpdatedAt": false }, { "name": "key", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "selector", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "value", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "user", "kind": "object", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "User", "relationName": "StepToUser", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }, { "name": "test", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Test", "relationName": "StepToTest", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }], "isGenerated": false }, { "name": "Tag", "isEmbedded": false, "dbName": null, "fields": [{ "name": "id", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": true, "type": "String", "default": { "name": "cuid", "returnType": "String", "args": [] }, "isGenerated": false, "isUpdatedAt": false }, { "name": "name", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "user", "kind": "object", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "User", "relationName": "TagToUser", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }, { "name": "test", "kind": "object", "dbName": null, "isList": false, "isRequired": false, "isUnique": false, "isId": false, "type": "Test", "relationName": "TagToTest", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": true, "isUpdatedAt": false }], "isGenerated": false }, { "name": "Test", "isEmbedded": false, "dbName": null, "fields": [{ "name": "id", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": true, "isId": true, "type": "String", "default": { "name": "cuid", "returnType": "String", "args": [] }, "isGenerated": false, "isUpdatedAt": false }, { "name": "user", "kind": "object", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "User", "relationName": "TestToUser", "relationToFields": ["id"], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }, { "name": "name", "kind": "scalar", "dbName": null, "isList": false, "isRequired": true, "isUnique": false, "isId": false, "type": "String", "isGenerated": false, "isUpdatedAt": false }, { "name": "tags", "kind": "object", "dbName": null, "isList": true, "isRequired": false, "isUnique": false, "isId": false, "type": "Tag", "relationName": "TagToTest", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }, { "name": "steps", "kind": "object", "dbName": null, "isList": true, "isRequired": false, "isUnique": false, "isId": false, "type": "Step", "relationName": "StepToTest", "relationToFields": [], "relationOnDelete": "NONE", "isGenerated": false, "isUpdatedAt": false }], "isGenerated": false }] }, "mappings": [{ "model": "User", "plural": "users", "findOne": "findOneUser", "findMany": "findManyUser", "create": "createOneUser", "delete": "deleteOneUser", "update": "updateOneUser", "deleteMany": "deleteManyUser", "updateMany": "updateManyUser", "upsert": "upsertOneUser" }, { "model": "Session", "plural": "sessions", "findOne": "findOneSession", "findMany": "findManySession", "create": "createOneSession", "delete": "deleteOneSession", "update": "updateOneSession", "deleteMany": "deleteManySession", "updateMany": "updateManySession", "upsert": "upsertOneSession" }, { "model": "Step", "plural": "steps", "findOne": "findOneStep", "findMany": "findManyStep", "create": "createOneStep", "delete": "deleteOneStep", "update": "updateOneStep", "deleteMany": "deleteManyStep", "updateMany": "updateManyStep", "upsert": "upsertOneStep" }, { "model": "Tag", "plural": "tags", "findOne": "findOneTag", "findMany": "findManyTag", "create": "createOneTag", "delete": "deleteOneTag", "update": "updateOneTag", "deleteMany": "deleteManyTag", "updateMany": "updateManyTag", "upsert": "upsertOneTag" }, { "model": "Test", "plural": "tests", "findOne": "findOneTest", "findMany": "findManyTest", "create": "createOneTest", "delete": "deleteOneTest", "update": "updateOneTest", "deleteMany": "deleteManyTest", "updateMany": "updateManyTest", "upsert": "upsertOneTest" }], "schema": { "enums": [{ "name": "OrderByArg", "values": ["asc", "desc"] }], "outputTypes": [{ "name": "Session", "fields": [{ "name": "id", "args": [], "outputType": { "type": "ID", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "token", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "user", "args": [], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }] }, { "name": "Tag", "fields": [{ "name": "id", "args": [], "outputType": { "type": "ID", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "name", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "user", "args": [], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }, { "name": "test", "args": [], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }] }, { "name": "Test", "fields": [{ "name": "id", "args": [], "outputType": { "type": "ID", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "user", "args": [], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }, { "name": "name", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "tags", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "TagOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": true } }, { "name": "steps", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "StepOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": true } }] }, { "name": "Step", "fields": [{ "name": "id", "args": [], "outputType": { "type": "ID", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "key", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "selector", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "value", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "user", "args": [], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }, { "name": "test", "args": [], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }] }, { "name": "User", "fields": [{ "name": "id", "args": [], "outputType": { "type": "ID", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "email", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "password", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "firstName", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "lastName", "args": [], "outputType": { "type": "String", "kind": "scalar", "isRequired": true, "isList": false } }, { "name": "session", "args": [], "outputType": { "type": "Session", "kind": "object", "isRequired": false, "isList": false } }, { "name": "step", "args": [], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": false } }, { "name": "tag", "args": [], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": false } }, { "name": "test", "args": [], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }] }, { "name": "Query", "fields": [{ "name": "findManyUser", "args": [{ "name": "where", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "UserOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": false, "isList": true } }, { "name": "findOneUser", "args": [{ "name": "where", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": false, "isList": false } }, { "name": "findManySession", "args": [{ "name": "where", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "SessionOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": false, "isList": true } }, { "name": "findOneSession", "args": [{ "name": "where", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": false, "isList": false } }, { "name": "findManyStep", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "StepOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": true } }, { "name": "findOneStep", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": false } }, { "name": "findManyTag", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "TagOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": true } }, { "name": "findOneTag", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": false } }, { "name": "findManyTest", "args": [{ "name": "where", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "orderBy", "inputType": [{ "isList": false, "isRequired": false, "type": "TestOrderByInput", "kind": "object" }] }, { "name": "skip", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "after", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "before", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "first", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "last", "inputType": [{ "type": "Int", "kind": "scalar", "isRequired": false, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": true } }, { "name": "findOneTest", "args": [{ "name": "where", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }] }, { "name": "BatchPayload", "fields": [{ "name": "count", "args": [], "outputType": { "type": "Int", "kind": "scalar", "isRequired": true, "isList": false } }] }, { "name": "Mutation", "fields": [{ "name": "createOneUser", "args": [{ "name": "data", "inputType": [{ "type": "UserCreateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteOneUser", "args": [{ "name": "where", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": false, "isList": false } }, { "name": "updateOneUser", "args": [{ "name": "data", "inputType": [{ "type": "UserUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": false, "isList": false } }, { "name": "upsertOneUser", "args": [{ "name": "where", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "UserCreateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "UserUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "User", "kind": "object", "isRequired": true, "isList": false } }, { "name": "updateManyUser", "args": [{ "name": "data", "inputType": [{ "type": "UserUpdateManyMutationInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteManyUser", "args": [{ "name": "where", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "createOneSession", "args": [{ "name": "data", "inputType": [{ "type": "SessionCreateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteOneSession", "args": [{ "name": "where", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": false, "isList": false } }, { "name": "updateOneSession", "args": [{ "name": "data", "inputType": [{ "type": "SessionUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": false, "isList": false } }, { "name": "upsertOneSession", "args": [{ "name": "where", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "SessionCreateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "SessionUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Session", "kind": "object", "isRequired": true, "isList": false } }, { "name": "updateManySession", "args": [{ "name": "data", "inputType": [{ "type": "SessionUpdateManyMutationInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteManySession", "args": [{ "name": "where", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "createOneStep", "args": [{ "name": "data", "inputType": [{ "type": "StepCreateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteOneStep", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": false } }, { "name": "updateOneStep", "args": [{ "name": "data", "inputType": [{ "type": "StepUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": false, "isList": false } }, { "name": "upsertOneStep", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "StepCreateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "StepUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Step", "kind": "object", "isRequired": true, "isList": false } }, { "name": "updateManyStep", "args": [{ "name": "data", "inputType": [{ "type": "StepUpdateManyMutationInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteManyStep", "args": [{ "name": "where", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "createOneTag", "args": [{ "name": "data", "inputType": [{ "type": "TagCreateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteOneTag", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": false } }, { "name": "updateOneTag", "args": [{ "name": "data", "inputType": [{ "type": "TagUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": false, "isList": false } }, { "name": "upsertOneTag", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TagCreateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TagUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Tag", "kind": "object", "isRequired": true, "isList": false } }, { "name": "updateManyTag", "args": [{ "name": "data", "inputType": [{ "type": "TagUpdateManyMutationInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteManyTag", "args": [{ "name": "where", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "createOneTest", "args": [{ "name": "data", "inputType": [{ "type": "TestCreateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteOneTest", "args": [{ "name": "where", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }, { "name": "updateOneTest", "args": [{ "name": "data", "inputType": [{ "type": "TestUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": false, "isList": false } }, { "name": "upsertOneTest", "args": [{ "name": "where", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TestCreateInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TestUpdateInput", "kind": "object", "isRequired": true, "isList": false }] }], "outputType": { "type": "Test", "kind": "object", "isRequired": true, "isList": false } }, { "name": "updateManyTest", "args": [{ "name": "data", "inputType": [{ "type": "TestUpdateManyMutationInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "where", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }, { "name": "deleteManyTest", "args": [{ "name": "where", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }] }], "outputType": { "type": "BatchPayload", "kind": "object", "isRequired": true, "isList": false } }] }], "inputTypes": [{ "name": "SessionWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "token", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "user", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "TagWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "name", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "user", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }, { "name": "test", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "TestWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "name", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "tags", "inputType": [{ "type": "TagFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "steps", "inputType": [{ "type": "StepFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "user", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "StepWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "key", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "selector", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "value", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "user", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }, { "name": "test", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "UserWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "email", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "password", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "firstName", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "lastName", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "UserWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "session", "inputType": [{ "type": "SessionWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }, { "name": "step", "inputType": [{ "type": "StepWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }, { "name": "tag", "inputType": [{ "type": "TagWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }, { "name": "test", "inputType": [{ "type": "TestWhereInput", "kind": "object", "isRequired": false, "isList": false }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "UserWhereUniqueInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }], "atLeastOne": true }, { "name": "SessionWhereUniqueInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }], "atLeastOne": true }, { "name": "StepWhereUniqueInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }], "atLeastOne": true }, { "name": "TagWhereUniqueInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }], "atLeastOne": true }, { "name": "TestWhereUniqueInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }], "atLeastOne": true }, { "name": "SessionCreateWithoutUserInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "token", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }] }, { "name": "SessionCreateOneWithoutSessionInput", "fields": [{ "name": "create", "inputType": [{ "type": "SessionCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagCreateWithoutUserInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagCreateOneWithoutTagInput", "fields": [{ "name": "create", "inputType": [{ "type": "TagCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserCreateWithoutTestInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionCreateOneWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepCreateOneWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagCreateOneWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserCreateOneWithoutUserInput", "fields": [{ "name": "create", "inputType": [{ "type": "UserCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagCreateWithoutTestInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TagCreateManyWithoutTagsInput", "fields": [{ "name": "create", "inputType": [{ "type": "TagCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "connect", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }] }, { "name": "TestCreateWithoutStepsInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagCreateManyWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestCreateOneWithoutTestInput", "fields": [{ "name": "create", "inputType": [{ "type": "TestCreateWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepCreateWithoutUserInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepCreateOneWithoutStepInput", "fields": [{ "name": "create", "inputType": [{ "type": "StepCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserCreateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionCreateOneWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepCreateOneWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagCreateOneWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "SessionUpdateWithoutUserDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "token", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "SessionUpsertWithoutUserInput", "fields": [{ "name": "update", "inputType": [{ "type": "SessionUpdateWithoutUserDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "SessionCreateWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "SessionUpdateOneWithoutUserInput", "fields": [{ "name": "create", "inputType": [{ "type": "SessionCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "SessionWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "SessionUpdateWithoutUserDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "SessionUpsertWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepCreateWithoutTestInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "StepCreateManyWithoutStepsInput", "fields": [{ "name": "create", "inputType": [{ "type": "StepCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "connect", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }] }, { "name": "TestCreateWithoutTagsInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepCreateManyWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserCreateWithoutStepInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionCreateOneWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagCreateOneWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestCreateWithoutUserInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagCreateManyWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepCreateManyWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserCreateWithoutTagInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionCreateOneWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepCreateOneWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateWithoutTagDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpsertWithoutTagInput", "fields": [{ "name": "update", "inputType": [{ "type": "UserUpdateWithoutTagDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "UserCreateWithoutTagInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "UserUpdateOneRequiredWithoutTagInput", "fields": [{ "name": "create", "inputType": [{ "type": "UserCreateWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "UserUpdateWithoutTagDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "UserUpsertWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateWithoutTestDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateWithWhereUniqueWithoutTestInput", "fields": [{ "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "data", "inputType": [{ "type": "TagUpdateWithoutTestDataInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TagScalarWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "name", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "TagScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "TagScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "TagScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "TagUpdateManyDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateManyWithWhereNestedInput", "fields": [{ "name": "where", "inputType": [{ "type": "TagScalarWhereInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "data", "inputType": [{ "type": "TagUpdateManyDataInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TagUpsertWithWhereUniqueWithoutTestInput", "fields": [{ "name": "where", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TagUpdateWithoutTestDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TagCreateWithoutTestInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TagUpdateManyWithoutTestInput", "fields": [{ "name": "create", "inputType": [{ "type": "TagCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "connect", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "set", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "disconnect", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "delete", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "update", "inputType": [{ "type": "TagUpdateWithWhereUniqueWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "updateMany", "inputType": [{ "type": "TagUpdateManyWithWhereNestedInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "deleteMany", "inputType": [{ "type": "TagScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "upsert", "inputType": [{ "type": "TagUpsertWithWhereUniqueWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }] }, { "name": "TestUpdateWithoutUserDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpsertWithoutUserInput", "fields": [{ "name": "update", "inputType": [{ "type": "TestUpdateWithoutUserDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TestCreateWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TestUpdateOneWithoutUserInput", "fields": [{ "name": "create", "inputType": [{ "type": "TestCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TestUpdateWithoutUserDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "TestUpsertWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateWithoutStepDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpsertWithoutStepInput", "fields": [{ "name": "update", "inputType": [{ "type": "UserUpdateWithoutStepDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "UserCreateWithoutStepInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "UserUpdateOneRequiredWithoutStepInput", "fields": [{ "name": "create", "inputType": [{ "type": "UserCreateWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "UserUpdateWithoutStepDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "UserUpsertWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateWithoutTestDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateWithWhereUniqueWithoutTestInput", "fields": [{ "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "data", "inputType": [{ "type": "StepUpdateWithoutTestDataInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "StepScalarWhereInput", "fields": [{ "name": "id", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "key", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "selector", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "value", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "type": "StringFilter", "isList": false, "isRequired": false, "kind": "object" }], "isRelationFilter": false }, { "name": "AND", "inputType": [{ "type": "StepScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "OR", "inputType": [{ "type": "StepScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }, { "name": "NOT", "inputType": [{ "type": "StepScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }], "isRelationFilter": true }], "isWhereType": true, "atLeastOne": false }, { "name": "StepUpdateManyDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateManyWithWhereNestedInput", "fields": [{ "name": "where", "inputType": [{ "type": "StepScalarWhereInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "data", "inputType": [{ "type": "StepUpdateManyDataInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "StepUpsertWithWhereUniqueWithoutTestInput", "fields": [{ "name": "where", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "update", "inputType": [{ "type": "StepUpdateWithoutTestDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "StepCreateWithoutTestInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "StepUpdateManyWithoutTestInput", "fields": [{ "name": "create", "inputType": [{ "type": "StepCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "connect", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "set", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "disconnect", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "delete", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "update", "inputType": [{ "type": "StepUpdateWithWhereUniqueWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "updateMany", "inputType": [{ "type": "StepUpdateManyWithWhereNestedInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "deleteMany", "inputType": [{ "type": "StepScalarWhereInput", "kind": "object", "isRequired": false, "isList": true }] }, { "name": "upsert", "inputType": [{ "type": "StepUpsertWithWhereUniqueWithoutTestInput", "kind": "object", "isRequired": false, "isList": true }] }] }, { "name": "TestUpdateWithoutTagsDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpsertWithoutTagsInput", "fields": [{ "name": "update", "inputType": [{ "type": "TestUpdateWithoutTagsDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TestCreateWithoutTagsInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TestUpdateOneWithoutTagsInput", "fields": [{ "name": "create", "inputType": [{ "type": "TestCreateWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TestUpdateWithoutTagsDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "TestUpsertWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateWithoutUserDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpsertWithoutUserInput", "fields": [{ "name": "update", "inputType": [{ "type": "TagUpdateWithoutUserDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TagCreateWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TagUpdateOneWithoutUserInput", "fields": [{ "name": "create", "inputType": [{ "type": "TagCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TagWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TagUpdateWithoutUserDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "TagUpsertWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateWithoutTestDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpsertWithoutTestInput", "fields": [{ "name": "update", "inputType": [{ "type": "UserUpdateWithoutTestDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "UserCreateWithoutTestInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "UserUpdateOneRequiredWithoutTestInput", "fields": [{ "name": "create", "inputType": [{ "type": "UserCreateWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "UserUpdateWithoutTestDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "UserUpsertWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpdateWithoutStepsDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpsertWithoutStepsInput", "fields": [{ "name": "update", "inputType": [{ "type": "TestUpdateWithoutStepsDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "TestCreateWithoutStepsInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "TestUpdateOneWithoutStepsInput", "fields": [{ "name": "create", "inputType": [{ "type": "TestCreateWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "TestWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "TestUpdateWithoutStepsDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "TestUpsertWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateWithoutUserDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpsertWithoutUserInput", "fields": [{ "name": "update", "inputType": [{ "type": "StepUpdateWithoutUserDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "StepCreateWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "StepUpdateOneWithoutUserInput", "fields": [{ "name": "create", "inputType": [{ "type": "StepCreateWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "StepWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "disconnect", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "delete", "inputType": [{ "type": "Boolean", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "StepUpdateWithoutUserDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "StepUpsertWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "session", "inputType": [{ "type": "SessionUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateManyMutationInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "SessionCreateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "token", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "UserCreateWithoutSessionInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepCreateOneWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagCreateOneWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpdateWithoutSessionDataInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "email", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "password", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "firstName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "lastName", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "step", "inputType": [{ "type": "StepUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tag", "inputType": [{ "type": "TagUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutUserInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "UserUpsertWithoutSessionInput", "fields": [{ "name": "update", "inputType": [{ "type": "UserUpdateWithoutSessionDataInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "create", "inputType": [{ "type": "UserCreateWithoutSessionInput", "kind": "object", "isRequired": true, "isList": false }] }] }, { "name": "UserUpdateOneRequiredWithoutSessionInput", "fields": [{ "name": "create", "inputType": [{ "type": "UserCreateWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "connect", "inputType": [{ "type": "UserWhereUniqueInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "update", "inputType": [{ "type": "UserUpdateWithoutSessionDataInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "upsert", "inputType": [{ "type": "UserUpsertWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "SessionUpdateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "token", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutSessionInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "SessionUpdateManyMutationInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "token", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "StepCreateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutStepInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "StepUpdateManyMutationInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "key", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "selector", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "value", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "TagCreateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestCreateOneWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutTagInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "test", "inputType": [{ "type": "TestUpdateOneWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TagUpdateManyMutationInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "TestCreateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": true, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserCreateOneWithoutUserInput", "kind": "object", "isRequired": true, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagCreateManyWithoutTagsInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepCreateManyWithoutStepsInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpdateInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "user", "inputType": [{ "type": "UserUpdateOneRequiredWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "tags", "inputType": [{ "type": "TagUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }, { "name": "steps", "inputType": [{ "type": "StepUpdateManyWithoutTestInput", "kind": "object", "isRequired": false, "isList": false }] }] }, { "name": "TestUpdateManyMutationInput", "fields": [{ "name": "id", "inputType": [{ "type": "ID", "kind": "scalar", "isRequired": false, "isList": false }] }, { "name": "name", "inputType": [{ "type": "String", "kind": "scalar", "isRequired": false, "isList": false }] }] }, { "name": "StringFilter", "fields": [{ "name": "equals", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "not", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }, { "isList": false, "isRequired": false, "kind": "scalar", "type": "StringFilter" }] }, { "name": "in", "inputType": [{ "isList": true, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "notIn", "inputType": [{ "isList": true, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "lt", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "lte", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "gt", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "gte", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "contains", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "startsWith", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }, { "name": "endsWith", "inputType": [{ "isList": false, "isRequired": false, "kind": "scalar", "type": "String" }] }], "atLeastOne": false }, { "name": "TagFilter", "fields": [{ "name": "every", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "TagWhereInput" }] }, { "name": "some", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "TagWhereInput" }] }, { "name": "none", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "TagWhereInput" }] }], "atLeastOne": false }, { "name": "StepFilter", "fields": [{ "name": "every", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "StepWhereInput" }] }, { "name": "some", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "StepWhereInput" }] }, { "name": "none", "inputType": [{ "isList": false, "isRequired": false, "kind": "object", "type": "StepWhereInput" }] }], "atLeastOne": false }, { "name": "UserOrderByInput", "atLeastOne": true, "atMostOne": true, "isOrderType": true, "fields": [{ "name": "id", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "email", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "password", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "firstName", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "lastName", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }] }, { "name": "TagOrderByInput", "atLeastOne": true, "atMostOne": true, "isOrderType": true, "fields": [{ "name": "id", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "name", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }] }, { "name": "StepOrderByInput", "atLeastOne": true, "atMostOne": true, "isOrderType": true, "fields": [{ "name": "id", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "key", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "selector", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "value", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }] }, { "name": "SessionOrderByInput", "atLeastOne": true, "atMostOne": true, "isOrderType": true, "fields": [{ "name": "id", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "token", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }] }, { "name": "TestOrderByInput", "atLeastOne": true, "atMostOne": true, "isOrderType": true, "fields": [{ "name": "id", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }, { "name": "name", "inputType": [{ "type": "OrderByArg", "isList": false, "isRequired": false, "kind": "enum" }], "isRelationFilter": false }] }] } };

module.exports = Photon; // needed to support const Photon = require('...') in js
Object.defineProperty(module.exports, "__esModule", { value: true });
for (let key in exports) {
  if (exports.hasOwnProperty(key)) {
    module.exports[key] = exports[key];
  }
}